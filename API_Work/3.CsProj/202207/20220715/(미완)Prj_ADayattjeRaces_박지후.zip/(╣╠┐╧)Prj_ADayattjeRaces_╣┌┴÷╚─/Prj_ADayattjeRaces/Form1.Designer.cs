﻿
namespace Prj_ADayattjeRaces
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.DogNumber_ud = new System.Windows.Forms.NumericUpDown();
            this.Bets_ud = new System.Windows.Forms.NumericUpDown();
            this.buttonofRace = new System.Windows.Forms.Button();
            this.buttonofBets = new System.Windows.Forms.Button();
            this.Al_label = new System.Windows.Forms.Label();
            this.Bob_label = new System.Windows.Forms.Label();
            this.Joe_label = new System.Windows.Forms.Label();
            this.Al_rdb = new System.Windows.Forms.RadioButton();
            this.Bob_rdb = new System.Windows.Forms.RadioButton();
            this.Joe_rdb = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DogNumber_ud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bets_ud)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(957, 366);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(26, 24);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(118, 57);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(26, 99);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(118, 57);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(26, 271);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(118, 57);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(26, 188);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(118, 57);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.DogNumber_ud);
            this.groupBox1.Controls.Add(this.Bets_ud);
            this.groupBox1.Controls.Add(this.buttonofRace);
            this.groupBox1.Controls.Add(this.buttonofBets);
            this.groupBox1.Controls.Add(this.Al_label);
            this.groupBox1.Controls.Add(this.Bob_label);
            this.groupBox1.Controls.Add(this.Joe_label);
            this.groupBox1.Controls.Add(this.Al_rdb);
            this.groupBox1.Controls.Add(this.Bob_rdb);
            this.groupBox1.Controls.Add(this.Joe_rdb);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(26, 372);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(917, 169);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Betting Parlor";
            // 
            // DogNumber_ud
            // 
            this.DogNumber_ud.Location = new System.Drawing.Point(577, 138);
            this.DogNumber_ud.Name = "DogNumber_ud";
            this.DogNumber_ud.Size = new System.Drawing.Size(120, 23);
            this.DogNumber_ud.TabIndex = 15;
            this.DogNumber_ud.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // Bets_ud
            // 
            this.Bets_ud.Location = new System.Drawing.Point(174, 141);
            this.Bets_ud.Name = "Bets_ud";
            this.Bets_ud.Size = new System.Drawing.Size(120, 23);
            this.Bets_ud.TabIndex = 14;
            this.Bets_ud.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // buttonofRace
            // 
            this.buttonofRace.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.buttonofRace.Location = new System.Drawing.Point(781, 127);
            this.buttonofRace.Name = "buttonofRace";
            this.buttonofRace.Size = new System.Drawing.Size(101, 38);
            this.buttonofRace.TabIndex = 13;
            this.buttonofRace.Text = "Race!";
            this.buttonofRace.UseVisualStyleBackColor = true;
            // 
            // buttonofBets
            // 
            this.buttonofBets.Font = new System.Drawing.Font("맑은 고딕", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonofBets.Location = new System.Drawing.Point(76, 138);
            this.buttonofBets.Name = "buttonofBets";
            this.buttonofBets.Size = new System.Drawing.Size(75, 23);
            this.buttonofBets.TabIndex = 10;
            this.buttonofBets.Text = "Bets";
            this.buttonofBets.UseVisualStyleBackColor = true;
            // 
            // Al_label
            // 
            this.Al_label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Al_label.Location = new System.Drawing.Point(577, 97);
            this.Al_label.Name = "Al_label";
            this.Al_label.Size = new System.Drawing.Size(305, 19);
            this.Al_label.TabIndex = 9;
            this.Al_label.Text = "label7";
            // 
            // Bob_label
            // 
            this.Bob_label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Bob_label.Location = new System.Drawing.Point(577, 73);
            this.Bob_label.Name = "Bob_label";
            this.Bob_label.Size = new System.Drawing.Size(305, 24);
            this.Bob_label.TabIndex = 8;
            this.Bob_label.Text = "label6";
            // 
            // Joe_label
            // 
            this.Joe_label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Joe_label.Location = new System.Drawing.Point(577, 48);
            this.Joe_label.Name = "Joe_label";
            this.Joe_label.Size = new System.Drawing.Size(305, 25);
            this.Joe_label.TabIndex = 7;
            this.Joe_label.Text = "label5";
            // 
            // Al_rdb
            // 
            this.Al_rdb.AutoSize = true;
            this.Al_rdb.Location = new System.Drawing.Point(6, 103);
            this.Al_rdb.Name = "Al_rdb";
            this.Al_rdb.Size = new System.Drawing.Size(14, 13);
            this.Al_rdb.TabIndex = 6;
            this.Al_rdb.TabStop = true;
            this.Al_rdb.UseVisualStyleBackColor = true;
            // 
            // Bob_rdb
            // 
            this.Bob_rdb.AutoSize = true;
            this.Bob_rdb.Location = new System.Drawing.Point(6, 78);
            this.Bob_rdb.Name = "Bob_rdb";
            this.Bob_rdb.Size = new System.Drawing.Size(14, 13);
            this.Bob_rdb.TabIndex = 5;
            this.Bob_rdb.TabStop = true;
            this.Bob_rdb.UseVisualStyleBackColor = true;
            // 
            // Joe_rdb
            // 
            this.Joe_rdb.AutoSize = true;
            this.Joe_rdb.Location = new System.Drawing.Point(6, 53);
            this.Joe_rdb.Name = "Joe_rdb";
            this.Joe_rdb.Size = new System.Drawing.Size(14, 13);
            this.Joe_rdb.TabIndex = 4;
            this.Joe_rdb.TabStop = true;
            this.Joe_rdb.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(577, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Bets";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(332, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "bucks on dog number";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(6, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(0, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Minimum bet";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 553);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DogNumber_ud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Bets_ud)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Al_rdb;
        private System.Windows.Forms.RadioButton Bob_rdb;
        private System.Windows.Forms.RadioButton Joe_rdb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonofRace;
        private System.Windows.Forms.Button buttonofBets;
        private System.Windows.Forms.Label Al_label;
        private System.Windows.Forms.Label Bob_label;
        private System.Windows.Forms.Label Joe_label;
        private System.Windows.Forms.NumericUpDown Bets_ud;
        private System.Windows.Forms.NumericUpDown DogNumber_ud;
    }
}

