#include "PRIME.h"

char str[20][128];

FILE* fp;
FILE* fp2;
